// ╔══════════════════════════════════════════════════╗
// ║  CV – Gabriel Rovesti  (English Version)        ║
// ╚══════════════════════════════════════════════════╝

#let primary    = rgb("#1a4a8a")
#let accent     = rgb("#2d7dd2")
#let sidebar-bg = rgb("#f0f3f8")
#let tag-fill   = rgb("#dce8f7")
#let tag-stroke = rgb("#a8c4e8")
#let muted      = rgb("#5a6272")
#let body-black = rgb("#1c2430")

// ── geometry ──────────────────────────────────────
#let sb-w     = 68mm
#let sb-pad-x = 10pt
#let rh-pad-l = 14pt
#let rh-pad-r = 14pt
#let mg-t     = 13pt
#let mg-b     = 13pt

#set page(
  paper: "a4",
  margin: (top: mg-t, bottom: mg-b, left: sb-w + rh-pad-l, right: rh-pad-r),
  background: place(
    top + left,
    rect(width: sb-w, height: 100%, fill: sidebar-bg)
  ),
)

#set text(font: "New Computer Modern", size: 10pt, fill: body-black)
#set par(justify: true, leading: 0.52em)
#show heading: set text(font: "New Computer Modern Sans", fill: primary)

// ── functions ─────────────────────────────────────

// Skill chip/tag
#let skill(s) = box(
  inset: (x: 4pt, y: 2pt),
  radius: 2pt,
  fill: tag-fill,
  stroke: 0.4pt + tag-stroke,
  text(size: 7pt, fill: primary, s)
)

#let sb-sec(title) = {
  v(5pt)
  text(fill: primary, weight: "bold", size: 8.5pt, upper(title))
  v(-5pt)
  line(length: 100%, stroke: 0.5pt + primary)
  v(2pt)
}

#let sec(title) = {
  v(7pt)
  text(fill: primary, weight: "bold", size: 10pt, upper(title))
  v(-5pt)
  line(length: 100%, stroke: 0.7pt + primary)
  v(3pt)
}

#let job(role, company, period, body) = {
  v(3pt)
  grid(
    columns: (1fr, auto),
    text(weight: "bold", size: 10pt)[#role],
    text(size: 8.5pt, fill: muted, style: "italic")[#period],
  )
  text(size: 9pt, fill: accent)[#company]
  v(1pt)
  body
  v(1pt)
}

#let edu(degree, school, period, body) = {
  v(3pt)
  grid(
    columns: (1fr, auto),
    text(weight: "bold", size: 10pt)[#degree],
    text(size: 8.5pt, fill: muted, style: "italic")[#period],
  )
  text(size: 9pt, fill: accent)[#school]
  v(1pt)
  body
  v(1pt)
}

// Sidebar project: vertical layout
#let proj-sb(title, tech, desc) = {
  v(4pt)
  text(weight: "bold", size: 9pt)[#title]
  linebreak()
  text(size: 7.5pt, fill: muted, style: "italic")[#tech]
  v(1pt)
  text(size: 9pt)[#desc]
  v(2pt)
}

// Place the sidebar in the left margin area
#let place-sidebar(body) = place(
  top + left,
  dx: sb-pad-x - sb-w - rh-pad-l,
  box(width: sb-w - 2 * sb-pad-x)[#body]
)

// ─────────────────────────────────────────────────
// PAGE 1 — Sidebar
// ─────────────────────────────────────────────────

#place-sidebar[
  #v(4pt)
  #align(center)[
    #box(clip: true, radius: 50%, width: 62%)[
      #image("gabriel.jpg", width: 100%)
    ]
    #v(4pt)
    #text(size: 12pt, weight: "bold", fill: primary)[Gabriel Rovesti]
    #v(1pt)
    #text(size: 7.5pt, fill: muted, style: "italic")[
      IT Consultant · Full Stack Developer \
      Lecturer & University Tutor
    ]
  ]

  #sb-sec("Contacts")
  #set text(size: 8pt)
  ✉ #link("mailto:rovestigabriel@gmail.com")[rovestigabriel\@gmail.com] \
  #v(1pt)
  ✆ +39 346 688 9789 \
  #v(1pt)
  ⌂ Padova, Italy \
  #v(1pt)
  _GitHub and projects_: #link("https://github.com/gabrielrovesti")[github.com/gabrielrovesti] \
  #v(1pt)
  _LinkedIn profile_: #link("https://linkedin.com/in/gabriel-rovesti-601404220")[linkedin/gabriel-rovesti] \
  #v(1pt)
  _Portfolio and personal website_: #link("https://gabrielrovesti.github.io")[gabrielrovesti.github.io]

  // Skills as tags/chips — fluid layout that wraps automatically
  #sb-sec("Skills")
  #set text(size: 8pt)

  *Languages* \
  #v(1pt)
  #skill("Java") #skill("Python") #skill("TypeScript") #skill("Rust") \
  #skill("C/C\+\+") #skill("C\#") #skill("F\#") #skill("Kotlin") \
  #skill("Go") #skill("Solidity") #skill("SQL")

  #v(4pt)
  *Frontend & Mobile* \
  #v(1pt)
  #skill("React") #skill("React Native") #skill("Angular") \
  #skill("Flutter") #skill("WebAssembly")

  #v(4pt)
  *Backend & Cloud* \
  #v(1pt)
  #skill("Spring Boot") #skill("FastAPI") #skill(".NET") \
  #skill("PostgreSQL") #skill("MongoDB") #skill("Redis") \
  #skill("AWS") #skill("GCP") #skill("Docker") #skill("Kubernetes")

  #v(4pt)
  *Specializations* \
  #v(1pt)
  #skill("WCAG 2.2") #skill("AI Agents") #skill("LLM") \
  #skill("Reactive Systems") #skill("ML/AI") #skill("Functional Prog.")

  #sb-sec("Certifications")
  #set text(size: 8pt)
  • Lightbend Reactive Architecture \
  • Kubernetes LFS158 — Linux Fnd. \
  • Cisco Networking · Ethical Hacking \
  • Cambridge B2 First (English) \
  • Datadog Fundamentals · Six Sigma \
  • Google Marketing Foundations

  #sb-sec("Languages")
  #set text(size: 8pt)
  #grid(
    columns: (1fr, auto),
    row-gutter: 2pt,
    column-gutter: 4pt,
    [Italian], [C2 — Native],
    [English],  [C1 — Advanced],
    [French], [B1 — Intermediate],
    [Spanish], [A2 — Basic],
  )

  #sb-sec("Honours & Awards")
  #set text(size: 8pt)
  • *Top 50 STEM* – UniPD 2024/25 \
  #v(1pt)
  • *2nd place* – UniPD Website Accessibility \
  #v(1pt)
  • *Bronze* – Interregional Karate \
  #v(1pt)
  • Regional scholarships 2019–2022

]

// ─────────────────────────────────────────────────
// PAGE 1 — Main content
// ─────────────────────────────────────────────────

// Summary: 3 concise lines with ▸, blue left border
#block(
  width: 100%,
  stroke: (left: 3pt + primary),
  inset: (left: 10pt, top: 5pt, bottom: 5pt, right: 0pt),
)[
  #set text(size: 9pt)
  - *IT Consultant* @ Technology Reply (Java/Spring Boot, AWS, Angular) — MSc graduate from UniPD *104/110*, Top 50 STEM out of 300+; 10+ years across software development, consulting and IT teaching
  - Specialized in *AI & intelligent agents*, mobile accessibility (WCAG 2.2), reactive systems and ML/AI; strong interest in integrating LLMs into enterprise systems and in autonomous agent design
  - *Lecturer and tutor* with 400+ documented university hours; expert in advanced technical training and inclusive support (SLD/SEN/autism)
]

#sec("Professional Experience")

#job("IT Consultant", "Technology Reply – Padova", "09/2025 – Present")[
  - Backend development with *Java / Spring Boot* for enterprise clients in the banking sector
  - Deployment and orchestration on *AWS*; frontend integration with *Angular*
  - Design of cloud-native microservices architectures for digital transformation projects
]

#job("Teacher – Systems and Networks (Technical Institute)", "ITI Galileo Ferraris – Padova", "09/2024 – 06/2025")[
  - Teaching network architectures, protocols and security to ~90 students (years 4–5)
  - Development of practical labs with Cisco Packet Tracer and Linux networking tools
]

#job("Teaching and Coordination Tutor", "University of Padova – Department of Mathematics", "10/2023 – 09/2025")[
  - *Coordination Tutor*: management of 15+ tutors across bachelor's and master's degree courses
  - *Teaching Tutor*: Automata and Formal Languages, OOP (bachelor's); Computability (master's, in English)
  - Production of advanced teaching materials; documented support for hundreds of students
]

#job("Inclusion Tutor & Accessibility Consultant", "University of Padova – Disability Services", "10/2023 – 09/2025")[
  - 350+ hours of specialized support for students with SLD/SEN/Asperger's/autism in STEM
  - Management of personalized exams (ESS3/Cineca, Uniweb); reader and scribe tutor
  - Development of WCAG 2.1-compliant digital tools; seminars on university accessibility
]

#job("Curricular Intern – Blockchain Developer", "Sync Lab S.r.l. – Padova", "03/2023 – 06/2023")[
  - Implementation of an Ethereum DApp POC with EthersJS/Web3JS and W3C standards (SSI/DID)
  - Study and application of Zero-Knowledge Proof techniques for identity verification
]

#job("Private Teacher & IT Consultant", "Freelance – Italy", "02/2016 – Present")[
  - 10+ years of tutoring in computer science, mathematics and languages; experienced with students with SLD/ADHD
  - Creation of WordPress/WooCommerce websites and Google Ads campaigns for SMEs
]

#job("Technical Lead & Data Manager", "Clesp S.r.l. – Padova", "07/2020 – 10/2021")[
  - Management of MySQL databases and development of KPI dashboards for 500+ Buffetti stores
  - Team leadership in customer service and automation of operational procedures
]

// ─────────────────────────────────────────────────
// PAGE 2
// ─────────────────────────────────────────────────

#pagebreak()

#place-sidebar[
  #v(4pt)
  #sb-sec("Selected Projects")

  #proj-sb(
    "AccessibleHub",
    "React Native · TypeScript · WCAG 2.2",
    [Master's thesis: React Native toolkit implementing WCAG 2.2, MCAG and WCAG2Mobile with interactive modules and a real-device demo.]
  )

  #proj-sb(
    "TinyML Interpreter",
    "F\# · Hindley-Milner",
    [Purely functional ML language interpreter with HM type inference.]
  )

  #proj-sb(
    "PredictSense",
    "Python · FastAPI · RabbitMQ · TF",
    [Microservices anomaly detection pipeline with asynchronous messaging and real-time dashboard.]
  )

  #proj-sb(
    "FlutterRustImageFX",
    "Flutter · Rust · WebAssembly",
    [Cross-platform photo editor: Flutter UI + Rust/WASM filters, 3× faster than pure JS.]
  )

  #proj-sb(
    "Event Processing Platform",
    "Spring WebFlux · Redis · MongoDB",
    [Reactive system: 10K+ events/sec with latency \<50ms.]
  )

  #proj-sb(
    "PCB Drilling Optimiser",
    "CPLEX · Tabu Search · C\+\+",
    [Exact and metaheuristic algorithms for PCB drilling; efficiency up to 84%.]
  )

  #proj-sb(
    "VerifiedMovies",
    "Ethereum · Solidity · ZKP",
    [Bachelor's thesis: blockchain DApp with Self-Sovereign Identity and Zero-Knowledge Proof.]
  )
]

// Main content page 2
#sec("Education")

#edu("Master's Degree in Computer Science — 104/110", "University of Padova", "09/2023 – 07/2025")[
  *Major:* Internet, Mobile and Security (IMS) — mobile security, wireless networks, advanced cryptography, big data \
  *Minor:* Innovation and Entrepreneurship in ICT — startup management, ITIL, NIST \
  *Thesis:* _Designing an accessibility learning toolkit: bridging the gap between guidelines and implementation_ \
  *Extra:* 400+ hours of university tutoring (inclusion, coordination, teaching, information services)
]

#edu("Bachelor's Degree in Computer Science — 98/110", "University of Padova", "09/2020 – 07/2023")[
  Algorithms, databases, concurrent programming, software engineering, accessible web development, advanced mathematics. \
  *Thesis:* _VerifiedMovies — security and authentication through blockchain_
]

#edu("High School Diploma in Computer Science — 100/100", "I.I.S. Polo Tecnico di Adria", "09/2015 – 06/2020")[
  Programming in C/C\+\+/Java, Cisco networks, web development (HTML/CSS/JS/PHP), Android, database design. ECDL certification.
]

#sec("Internships, Contributions and Other Activities")

#job("Election Clerk", "Municipality of Padova", "2024 – 2025")[
  - Official election clerk in municipal, regional and national electoral operations
]

#job("IT Application Configurator", "Digife S.r.l. – Ferrara", "01/2019 – 02/2019")[
  - Development of WordPress websites with WooCommerce plugins; newsletter creation; SEO copywriting
]

#job("Administrative Assistant", "CIERRE Elettronica – Serravalle (FE)", "06/2018 – 07/2018")[
  - Equipment management, order filing, operational support to the department manager
]

#job("Author and Contributor", "Wikipedia (Italian/English)", "2018 – Present")[
  - Active contributions to technical and scientific entries in Italian and English
  - Review and creation of content in computer science and mathematics
]